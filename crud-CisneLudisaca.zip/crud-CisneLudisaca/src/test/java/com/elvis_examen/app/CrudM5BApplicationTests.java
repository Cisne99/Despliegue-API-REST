package com.elvis_examen.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudM5BApplicationTests {

	@Test
	void contextLoads() {
	}

}
