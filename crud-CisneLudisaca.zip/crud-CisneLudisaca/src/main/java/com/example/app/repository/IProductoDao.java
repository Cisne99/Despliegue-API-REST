package com.example.app.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.example.app.models.ProductoDTO;

@Repository
public interface IProductoDao extends MongoRepository<ProductoDTO, String> {

}
